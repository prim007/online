<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta content="IE=edge" http-equiv="X-UA-Compatible">
	<meta content="width=device-width, initial-scale=1.0" name="viewport">
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet">
	<title>ADMIN DASHBOARD</title>
</head>
<body>
	<div class="container-fliud">
		<nav class="navbar navbar-expand-lg navbar-light bg-success">
			<a class="navbar-brand" href="#">BIKE STORE</a> <button aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation" class="navbar-toggler" data-bs-target="#navbarSupportedContent" data-bs-toggle="collapse" type="button"><span class="navbar-toggler-icon"></span></button>
		</nav>
		<nav class="navbar navbar-expand-lg">
			<ul class="navbar-nav">
				<li class="nav-item">
					<a class="nav-link" href="">Welcome Guest</a>
				</li>
			</ul>
		</nav>



        <div class="bg-light">
            <h3 class="text-center p-2">Manage Accounts</h3>
            <!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<div class="row">
		<div class="col=md-12 bg-secondary p-1">
			<div>
				<a href=""><img src="">
				<p class="text-light text-center">Admin Name</p></a>
			</div>
			<div class="button text-center">
				<button><a class="nav-link text-light bg-success my-1" href="">View Products</a></button> <button><a class="nav-link text-light bg-success my-1" href="">lnsert Products</a></button> <button><a class="nav-link text-light bg-success my-1" href="index.php?insert_category">lnsert Category</a></button> <button><a class="nav-link text-light bg-success my-1" href="index.php?insert_brands">lnsert Brands</a></button>
			</div>
		</div>
		<div></div>


        <div class="container my-5">
            <?php
            if(isset($_GET['insert_category']))
            include('insert_categories.php');

            if(isset($_GET['insert_brands']))
            include('insert_brands.php');


            ?>
</div>
		<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.5/dist/umd/popper.min.js">
		</script> 
		<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.min.js">
		</script> 
	</div>
</body>
</html>