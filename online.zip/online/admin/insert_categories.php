<?php
include('../includes/connect.php');
?>

<form actions="" method="post" class="mb-2">
<div class="input-group w-90 mb-3">
  <span class="input-group-text bg-success" id="basic-addon1">Add Category</span>
  <input type="text" class="form-control" name="cat_title" placeholder="insert categories" aria-label="Username" aria-describedby="basic-addon1">
</div>
<div class="input-group w-10 mb-2">
 
  <!--<input type="submit" class="form-control bg-success" name="insert_cat" value="insert categories">-->
  <button class="bg-success p-3 m-3 border-0">Insert Categories</button>
</div>
</form>