<?php

/*connection to the database*/
$con=mysqli_connect('localhost', 'root', '','store');
if(!$con){
    echo "connection is successful";

}

?>