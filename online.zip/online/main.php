<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta content="IE=edge" http-equiv="X-UA-Compatible">
	<meta content="width=device-width, initial-scale=1.0" name="viewport">
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet">
	<title>BIKE STORE</title>
</head>
<body>
	<!--navbar-->
	<div class="container-fliud">
		<nav class="navbar navbar-expand-lg bg-success">
			<div class="container-fluid">
				<a class="navbar-brand" href="#">BIKE STORE</a> <button aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation" class="navbar-toggler" data-bs-target="#navbarSupportedContent" data-bs-toggle="collapse" type="button"><span class="navbar-toggler-icon"></span></button>
				<div class="collapse navbar-collapse" id="navbarSupportedContent">
					<ul class="navbar-nav me-auto mb-2 mb-lg-0">
						<li class="nav-item">
							<a class="nav-link active" href="#">Home</a>
						</li>
						<li class="nav-item">
							<a class="nav-link" href="#">View Products</a>
						</li>
						<li class="nav-item">
							<a class="nav-link" href="#">Sign Up</a>
						</li>
						<li class="nav-item">
							<a class="nav-link" href="#">Cart</a>
						</li>
						<li class="nav-item">
							<a class="nav-link" href="#">Price</a>
						</li>
					</ul>
					<form class="d-flex" role="search">
						<input aria-label="Search" class="form-control me-2" placeholder="Search" type="search"> <button class="btn btn-outline-success" type="submit">Search</button>
					</form>
				</div>
			</div>
		</nav>
		<nav class="navbar navbar-expand-lg navbar-dark bg-secondary">
			<ul class="navbar-nav me-auto">
				<li class="nav-item">
					<a class="nav-link" href="#">Welcome</a>
				</li>
				<li class="nav-item">
					<a class="nav-link" href="#">Login</a>
				</li>
			</ul>
		</nav>
		<div class="bg-light">
			<h3 class="text-center">Bikes</h3>
		</div>
		<div class="row">
			<div class="col-md-10">
				<div class="row">
					<div class="col-md-4">
						<div class="card" style="">
							<img alt="..." class="card-img-top" src="./img/bike.png">
							<div class="card-body">
								<h5 class="card-title">Cross country bike.</h5>
								<p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p><a class="btn btn-light" href="#">Add to Cart</a> <a class="btn btn-success" href="#">View More</a>
							</div>
						</div>
					</div>
					<div class="col-md-4">
						<div class="card" style="">
							<img alt="..." class="card-img-top" src="./img/bike.png">
							<div class="card-body">
								<h5 class="card-title">Cross country bike.</h5>
								<p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p><a class="btn btn-light" href="#">Add to Cart</a> <a class="btn btn-success" href="#">View More</a>
							</div>
						</div>
					</div>
					<div class="col-md-4">
						<div class="card" style="">
							<img alt="..." class="card-img-top" src="./img/bike.png">
							<div class="card-body">
								<h5 class="card-title">Cross country bike.</h5>
								<p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p><a class="btn btn-light" href="#">Add to Cart</a> <a class="btn btn-success" href="#">View More</a>
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="col-md-2 bg-secondary p-0">
				<ul class="navbar-nav me-auto text-center">
					<li class="nav-item bg-success">
						<a class="nav-link text-light" href="#">
						<h4>New Collection</h4></a>
					</li>
					<li class="nav-item">
						<a class="nav-link text-light" href="#">Brand 1</a>
					</li>
					<li class="nav-item">
						<a class="nav-link text-light" href="#">Brand 1</a>
					</li>
					<li class="nav-item">
						<a class="nav-link text-light" href="#">Brand 1</a>
					</li>
				</ul>
			</div>

            <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.5/dist/umd/popper.min.js" integrity="sha384-Xe+8cL9oJa6tN/veChSP7q+mnSPaj5Bcu9mPX5F5xIGE0DVittaqT5lorf0EI7Vk" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.min.js" integrity="sha384-ODmDIVzN+pFdexxHEHFBQH3/9/vQ9uori45z4JjnFsRydbmQbmL5t1tQ0culUzyK" crossorigin="anonymous"></script>
          
			<div class="bg-light p-3 text-center">
				<p>All rights reserved</p>
			</div>
		</div>
	</div>
</body>
</html>